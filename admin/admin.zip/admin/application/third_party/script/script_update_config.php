<?php
define("AUS_ROOT_URL", "https://update.suisesoft.tech");
define("AUS_PRODUCT_ID", 1);
define("AUS_PRODUCT_KEY", "7EpViyGNu70nSmYy");
define("AUS_NOTIFICATION_NO_CONNECTION", "Can't connect to updates server.");
define("AUS_NOTIFICATION_ZIPARCHIVE_CLASS_MISSING", "ZipArchive class is missing on this server.");
define("AUS_NOTIFICATION_ZIP_EXTRACT_ERROR", "Can't extract downloaded ZIP archive or write files.");
define("AUS_NOTIFICATION_ZIP_DELETE_ERROR", "Can't delete downloaded ZIP archive.");
define("AUS_DELETE_EXTRACTED", "YES");
define("AUS_CORE_NOTIFICATION_INVALID_ROOT_URL", "Configuration error: invalid root URL of CiuisCRM update server");
define("AUS_CORE_NOTIFICATION_INVALID_PRODUCT_ID", "Configuration error: invalid product ID");
define("AUS_CORE_NOTIFICATION_INVALID_PRODUCT_KEY", "Configuration error: invalid product key");
define("AUS_CORE_NOTIFICATION_INACCESSIBLE_ROOT_URL", "Server error: impossible to establish connection to your CiuisCRM");
define("AUS_DIRECTORY", BASEPATH);